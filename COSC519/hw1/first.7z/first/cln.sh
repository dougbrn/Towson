#!/bin/bash

#clean the directory

echo "Script File cln.sh"

rm hello 
rm hello.o
rm hello.lst
rm hello.s
rm hello.map

echo "Done"
